# ======================================================================================
# Copyright and other protections apply. Please see the accompanying LICENSE file for
# rights and restrictions governing use of this software. All rights not expressly
# waived or licensed are reserved. If that file is missing or appears to be modified
# from its original, then please contact the author before viewing or using this
# software in any capacity.
#
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# !!!!!!!!!!!!!!! IMPORTANT: READ THIS BEFORE EDITING! !!!!!!!!!!!!!!!
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# Please keep each docstring sentence on its own unwrapped line. It looks like crap in a
# text editor, but it has no effect on rendering, and it allows much more useful diffs.
# (This does not apply to code comments.) Thank you!
# ======================================================================================

r"""
!!! warning "Experimental"

    This package is an attempt to explore conveniences for integration with [Matplotlib](https://matplotlib.org/).
    It is an explicit departure from [RFC 1925, § 2.2](https://datatracker.ietf.org/doc/html/rfc1925#section-2) and should be considered experimental.
    Be warned that future release may introduce incompatibilities or remove this package altogether.
    [Feedback, suggestions, and contributions](contrib.md) are welcome and appreciated.
"""

if True:  # so ruff won't complain imports are out-of-order, but still sort the others
    from dyce.types import beartype_this_package

    beartype_this_package()

from importlib.metadata import PackageNotFoundError, version

__all__ = ()

try:
    __version__: str = version("anydyce")
except PackageNotFoundError:  # pragma: no cover
    __version__ = "0.0.0+unknown"
